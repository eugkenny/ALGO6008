public class Board {

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles){

    }

    // string representation of this board
    public String toString(){
        return null;
    }

    // tile at (row, col) or 0 if blank
    public int tileAt(int row, int col){
        return 0;
    }

    // board size n
    public int size(){
        return 0;
    }

    // number of tiles out of place
    public int hamming(){
        return 0;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan(){
        return 0;
    }

    // is this board the goal board?
    public boolean isGoal(){
        return false;
    }

    // does this board equal y?
    public boolean equals(Object y){
        return false;
    }

    // all neighboring boards
    public Iterable<Board> neighbors(){
        return null;
    }

    // unit testing (required)
    public static void main(String[] args){
        int[][] tiles = { {0, 1, 3}, {4, 2, 5}, {7, 8, 6} }; // puzzle04
        Board board = new Board(tiles);
        // Test each Board method
    }
}