import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class EightPuzzleSolver {

    // find a solution to the initial board (using the A* algorithm)
    public EightPuzzleSolver(Board initial){

    }

    // min number of moves to solve initial board
    public int moves(){
        return 0;
    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution(){
        return null;
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = 0;
        int[][] tiles = null;

        File file = new File("/home/eugkenny/Projects/EightPuzzleSolver/src/puzzle04.txt");
        //File file = new File(args[0]);

        try {
            Scanner sc = new Scanner(file);

            n = sc.nextInt();
            tiles = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    tiles[i][j] = sc.nextInt();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

/*        System.out.println(n);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(tiles[i][j]);
            }
            System.out.println();
        }*/

        Board initial = new Board(tiles);
        EightPuzzleSolver solver = new EightPuzzleSolver(initial);

        System.out.println("Minimum number of moves: " + solver.moves());

        for(Board board : solver.solution()){
            System.out.println(board);
        }
    }

    public static final class State implements Comparable<State>{
        Board board;        // The Board for this state
        State previous;     // The previous (parent) state
        int priority;           // The priority (heuristic) function
        int moves;          // Moves taken to get to the state

        private State (Board board, State previous){
            // YOUR CODE HERE
        }

        @Override
        public int compareTo(State other) {
            // YOUR CODE HERE
            return 0;
        }
    }
}
