public class QuadraticProbingHashMap<K, V> extends SimpleHashMap<K, V>{

    
    // DON'T CHANGE THIS - Bad things might happen
    @SuppressWarnings("unchecked")
    public QuadraticProbingHashMap(int initCapacity, double loadFactor){
        size = 0;
        this.loadFactor = loadFactor;
        if (initCapacity < MIN_TABLE_SIZE){
            capacity = MIN_TABLE_SIZE;
        }
        else{
            capacity = nextSuitablePrime(initCapacity);
        }
        table = (MapEntry<K,V> []) new MapEntry[capacity];
    }
 
    @Override
    public V get(K key){
        return null;
    }

    @Override
    public V put(K key, V value){
        V oldValue = null;
       
        return oldValue;
    }
}