public class DoubleHashingHashMap<K, V> extends SimpleHashMap<K, V>{
  
    @SuppressWarnings("unchecked")
    public DoubleHashingHashMap(int initCapacity, double loadFactor){
        size = 0;
        this.loadFactor = loadFactor;
        if (initCapacity < MIN_TABLE_SIZE){
            capacity = MIN_TABLE_SIZE;
        }
        else{
            capacity = nextSuitablePrime(initCapacity);
        }
        table = (MapEntry<K,V> []) new MapEntry[capacity];
    }

    @Override
    public V get(K key){
        return null;
    }

    @Override
    public V put(K key, V value){
        V oldValue = null;
       
        return oldValue;
    }
    
    protected int hash2(K key){
        return 0;
    }
}